import java.util.ArrayList;

public class Mascota {

    private String ID;
    private String nombre;
    private String tipoAnimal;
    private String raza;
    private String tamano;
    private int edad;
    private double peso;
    private HistoriaClinica historiaClinica;



}
